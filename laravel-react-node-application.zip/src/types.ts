export type TicketStatus = "DONE" | "ON GOING" | "PENDING" | "OPEN";
export type TicketPriority = "RAB" | "THD" | "EBT";

export interface Ticket {
  id: number;
  date: string;
  company: string;
  concern: string;
  anydeskOrPc: string;
  status: TicketStatus;
  completionDate: string;
  remarks: string;
  communication: string;
  priority: TicketPriority;
}

export interface User {
  id: number;
  name: string;
  email: string;
  role: string;
}

export interface AnalyticsData {
  totalTickets: number;
  doneTickets: number;
  ongoingTickets: number;
  pendingTickets: number;
  completionRate: number;
  ticketsByCompany: { name: string; value: number }[];
  ticketsByPriority: { name: string; value: number }[];
  ticketsByDate: { date: string; count: number }[];
  avgResolutionDays: number;
}
