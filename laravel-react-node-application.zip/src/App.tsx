import { useState, useEffect } from "react";
import LoginPage from "./components/LoginPage";
import Sidebar from "./components/Sidebar";
import Dashboard from "./components/Dashboard";
import TicketsPage from "./components/TicketsPage";
import AnalyticsPage from "./components/AnalyticsPage";
import { Ticket } from "./types";
import { initialTickets } from "./data";
import { api, storage } from "./api";
import { Bell, Search } from "lucide-react";

type Tab = "dashboard" | "tickets" | "analytics" | "settings";

export default function App() {
  const [user, setUser] = useState<{
    id: number;
    name: string;
    email: string;
    role: string;
  } | null>(null);
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [activeTab, setActiveTab] = useState<Tab>("dashboard");

  useEffect(() => {
    // Check if user is already logged in
    const authUser = storage.getAuth();
    if (authUser) {
      setUser(authUser);
    }

    // Load tickets from storage (or use initial data)
    const storedTickets = storage.getTickets();
    if (storedTickets.length === 0) {
      // Initialize with sample data
      initialTickets.forEach((ticket) => {
        storage.saveTickets([...storage.getTickets(), ticket]);
      });
      setTickets(initialTickets);
    } else {
      setTickets(storedTickets);
    }
  }, []);

  const handleLogin = (userData: { id: number; name: string; email: string; role: string }) => {
    setUser(userData);
  };

  const handleLogout = async () => {
    await api.logout();
    setUser(null);
    setActiveTab("dashboard");
  };

  const loadTickets = async () => {
    const data = await api.getTickets();
    setTickets(data);
  };

  const handleCreateTicket = async (ticketData: Omit<Ticket, "id">) => {
    await api.createTicket(ticketData);
    await loadTickets();
  };

  const handleUpdateTicket = async (id: number, updates: Partial<Ticket>) => {
    await api.updateTicket(id, updates);
    await loadTickets();
  };

  const handleDeleteTicket = async (id: number) => {
    await api.deleteTicket(id);
    await loadTickets();
  };

  if (!user) {
    return <LoginPage onLogin={handleLogin} />;
  }

  return (
    <div className="flex min-h-screen bg-slate-50">
      <Sidebar
        activeTab={activeTab}
        onTabChange={setActiveTab}
        user={user}
        onLogout={handleLogout}
      />

      <div className="flex-1 flex flex-col min-w-0">
        {/* Top Bar */}
        <header className="bg-white border-b border-slate-200 px-6 py-3 flex items-center justify-between sticky top-0 z-40">
          <div className="flex items-center gap-3 flex-1 max-w-xl">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="text"
                placeholder="Search tickets, companies..."
                className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-red-500/20 focus:border-red-500 outline-none text-sm"
              />
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button className="relative p-2 rounded-lg hover:bg-slate-100 text-slate-600">
              <Bell className="w-5 h-5" />
              <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
            </button>
            <div className="h-6 w-px bg-slate-200"></div>
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-red-500 to-red-600 flex items-center justify-center text-white font-semibold text-sm">
                {user.name.charAt(0)}
              </div>
              <div className="text-sm">
                <div className="font-semibold text-slate-900">{user.name}</div>
                <div className="text-xs text-slate-500">{user.role}</div>
              </div>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="flex-1 overflow-auto">
          {activeTab === "dashboard" && <Dashboard tickets={tickets} />}
          {activeTab === "tickets" && (
            <TicketsPage
              tickets={tickets}
              onCreateTicket={handleCreateTicket}
              onUpdateTicket={handleUpdateTicket}
              onDeleteTicket={handleDeleteTicket}
            />
          )}
          {activeTab === "analytics" && <AnalyticsPage tickets={tickets} />}
          {activeTab === "settings" && <SettingsPage user={user} />}
        </main>
      </div>
    </div>
  );
}

function SettingsPage({ user }: { user: { name: string; email: string; role: string } }) {
  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Settings</h1>
        <p className="text-slate-500 mt-1">Manage your account and preferences</p>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 p-6">
        <h3 className="font-semibold text-slate-900 mb-4">Profile Information</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <label className="text-sm font-medium text-slate-700">Full Name</label>
            <input
              type="text"
              defaultValue={user.name}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-red-500/20 focus:border-red-500 outline-none"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-sm font-medium text-slate-700">Email</label>
            <input
              type="email"
              defaultValue={user.email}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-red-500/20 focus:border-red-500 outline-none"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-sm font-medium text-slate-700">Role</label>
            <input
              type="text"
              defaultValue={user.role}
              disabled
              className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-slate-50 text-slate-500 outline-none"
            />
          </div>
        </div>
        <div className="mt-6">
          <button className="bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white font-semibold px-5 py-2 rounded-lg shadow-lg shadow-red-500/20 transition">
            Save Changes
          </button>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 p-6">
        <h3 className="font-semibold text-slate-900 mb-4">System Configuration</h3>
        <div className="space-y-4">
          {[
            { label: "Email Notifications", desc: "Receive email alerts for new tickets", checked: true },
            { label: "Auto-assign Tickets", desc: "Automatically assign tickets to available agents", checked: false },
            { label: "Daily Summary Report", desc: "Get daily summary of ticket activity", checked: true },
          ].map((item, i) => (
            <label key={i} className="flex items-start gap-3 cursor-pointer">
              <input
                type="checkbox"
                defaultChecked={item.checked}
                className="w-4 h-4 rounded border-slate-300 text-red-600 focus:ring-red-500 mt-1"
              />
              <div className="flex-1">
                <div className="font-medium text-slate-900">{item.label}</div>
                <div className="text-sm text-slate-500">{item.desc}</div>
              </div>
            </label>
          ))}
        </div>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 p-6">
        <h3 className="font-semibold text-slate-900 mb-4">API & Integration</h3>
        <div className="space-y-3 text-sm">
          <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
            <div>
              <div className="font-semibold text-slate-900">Laravel API Endpoint</div>
              <div className="text-slate-500 text-xs mt-0.5">REST API Base URL</div>
            </div>
            <code className="bg-white px-3 py-1 rounded border border-slate-200 text-xs">
              https://api.company.com/v1
            </code>
          </div>
          <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
            <div>
              <div className="font-semibold text-slate-900">Sanctum Token</div>
              <div className="text-slate-500 text-xs mt-0.5">Authentication</div>
            </div>
            <code className="bg-white px-3 py-1 rounded border border-slate-200 text-xs">
              ••••••••••••••••
            </code>
          </div>
          <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
            <div>
              <div className="font-semibold text-slate-900">Node.js Socket Server</div>
              <div className="text-slate-500 text-xs mt-0.5">Real-time notifications</div>
            </div>
            <span className="text-xs font-semibold px-2 py-1 bg-green-100 text-green-700 rounded-full">
              ● Connected
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
