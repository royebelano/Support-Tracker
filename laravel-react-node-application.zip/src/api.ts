import { Ticket } from "./types";

const STORAGE_KEY = "it_support_tickets";
const AUTH_KEY = "it_support_auth";

export const storage = {
  getTickets: (): Ticket[] => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      return JSON.parse(stored);
    }
    return [];
  },
  saveTickets: (tickets: Ticket[]) => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(tickets));
  },
  getAuth: () => {
    const stored = localStorage.getItem(AUTH_KEY);
    if (stored) {
      return JSON.parse(stored);
    }
    return null;
  },
  saveAuth: (user: { id: number; name: string; email: string; role: string }) => {
    localStorage.setItem(AUTH_KEY, JSON.stringify(user));
  },
  clearAuth: () => {
    localStorage.removeItem(AUTH_KEY);
  },
};

export const api = {
  // Simulate Laravel API calls with delay
  delay: (ms: number = 300) => new Promise((resolve) => setTimeout(resolve, ms)),

  login: async (email: string, password: string) => {
    await api.delay(600);
    // Mock users
    const users = [
      { id: 1, name: "Admin User", email: "admin@company.com", password: "admin123", role: "Administrator" },
      { id: 2, name: "Support Agent", email: "agent@company.com", password: "agent123", role: "Support Agent" },
    ];
    const user = users.find((u) => u.email === email && u.password === password);
    if (user) {
      const authData = { id: user.id, name: user.name, email: user.email, role: user.role };
      storage.saveAuth(authData);
      return authData;
    }
    throw new Error("Invalid email or password");
  },

  logout: async () => {
    await api.delay(200);
    storage.clearAuth();
  },

  getTickets: async (): Promise<Ticket[]> => {
    await api.delay(300);
    return storage.getTickets();
  },

  createTicket: async (ticket: Omit<Ticket, "id">): Promise<Ticket> => {
    await api.delay(300);
    const tickets = storage.getTickets();
    const newTicket = { ...ticket, id: tickets.length > 0 ? Math.max(...tickets.map((t) => t.id)) + 1 : 1 };
    tickets.push(newTicket);
    storage.saveTickets(tickets);
    return newTicket;
  },

  updateTicket: async (id: number, updates: Partial<Ticket>): Promise<Ticket> => {
    await api.delay(300);
    const tickets = storage.getTickets();
    const index = tickets.findIndex((t) => t.id === id);
    if (index === -1) throw new Error("Ticket not found");
    tickets[index] = { ...tickets[index], ...updates };
    storage.saveTickets(tickets);
    return tickets[index];
  },

  deleteTicket: async (id: number): Promise<void> => {
    await api.delay(300);
    const tickets = storage.getTickets();
    storage.saveTickets(tickets.filter((t) => t.id !== id));
  },
};

export function formatDate(dateStr: string): string {
  if (!dateStr) return "";
  const d = new Date(dateStr);
  return d.toLocaleDateString("en-US", { month: "2-digit", day: "2-digit", year: "numeric" });
}

export function getStatusColor(status: string): string {
  switch (status) {
    case "DONE":
      return "bg-green-100 text-green-800 border-green-300";
    case "ON GOING":
      return "bg-blue-100 text-blue-800 border-blue-300";
    case "PENDING":
      return "bg-yellow-100 text-yellow-800 border-yellow-300";
    case "OPEN":
      return "bg-red-100 text-red-800 border-red-300";
    default:
      return "bg-gray-100 text-gray-800 border-gray-300";
  }
}

export function getPriorityColor(priority: string): string {
  switch (priority) {
    case "RAB":
      return "bg-red-100 text-red-700 border-red-300";
    case "THD":
      return "bg-purple-100 text-purple-700 border-purple-300";
    case "EBT":
      return "bg-orange-100 text-orange-700 border-orange-300";
    default:
      return "bg-gray-100 text-gray-700 border-gray-300";
  }
}
