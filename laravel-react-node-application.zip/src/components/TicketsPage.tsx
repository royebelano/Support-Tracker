import { useState } from "react";
import { Search, Plus, Filter, Download, Edit2, Trash2, X, Save } from "lucide-react";
import { Ticket as TicketType } from "../types";
import { getStatusColor, getPriorityColor } from "../api";

interface TicketsPageProps {
  tickets: TicketType[];
  onCreateTicket: (ticket: Omit<TicketType, "id">) => void;
  onUpdateTicket: (id: number, updates: Partial<TicketType>) => void;
  onDeleteTicket: (id: number) => void;
}

export default function TicketsPage({
  tickets,
  onCreateTicket,
  onUpdateTicket,
  onDeleteTicket,
}: TicketsPageProps) {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("ALL");
  const [priorityFilter, setPriorityFilter] = useState<string>("ALL");
  const [showModal, setShowModal] = useState(false);
  const [editingTicket, setEditingTicket] = useState<TicketType | null>(null);
  const [formData, setFormData] = useState({
    date: new Date().toISOString().split("T")[0].replace(/\//g, "-").replace(/-/g, "/"),
    company: "",
    concern: "",
    anydeskOrPc: "",
    status: "OPEN" as TicketType["status"],
    completionDate: "",
    remarks: "",
    communication: "",
    priority: "RAB" as TicketType["priority"],
  });

  const filteredTickets = tickets.filter((t) => {
    const matchesSearch =
      search === "" ||
      t.company.toLowerCase().includes(search.toLowerCase()) ||
      t.concern.toLowerCase().includes(search.toLowerCase()) ||
      t.anydeskOrPc.includes(search);
    const matchesStatus = statusFilter === "ALL" || t.status === statusFilter;
    const matchesPriority = priorityFilter === "ALL" || t.priority === priorityFilter;
    return matchesSearch && matchesStatus && matchesPriority;
  });

  const handleCreate = () => {
    const parts = formData.date.split("/");
    const formattedDate = parts.length === 3 ? `${parts[0]}/${parts[1]}/${parts[2]}` : formData.date;
    onCreateTicket({
      ...formData,
      date: formattedDate,
    });
    setShowModal(false);
    resetForm();
  };

  const handleUpdate = () => {
    if (editingTicket) {
      onUpdateTicket(editingTicket.id, formData);
      setEditingTicket(null);
      setShowModal(false);
      resetForm();
    }
  };

  const resetForm = () => {
    setFormData({
      date: new Date().toISOString().split("T")[0].replace(/\//g, "-").replace(/-/g, "/"),
      company: "",
      concern: "",
      anydeskOrPc: "",
      status: "OPEN",
      completionDate: "",
      remarks: "",
      communication: "",
      priority: "RAB",
    });
  };

  const openEditModal = (ticket: TicketType) => {
    setEditingTicket(ticket);
    setFormData({
      date: ticket.date,
      company: ticket.company,
      concern: ticket.concern,
      anydeskOrPc: ticket.anydeskOrPc,
      status: ticket.status,
      completionDate: ticket.completionDate,
      remarks: ticket.remarks,
      communication: ticket.communication,
      priority: ticket.priority,
    });
    setShowModal(true);
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Support Tickets</h1>
          <p className="text-slate-500 mt-1">
            {filteredTickets.length} of {tickets.length} tickets
          </p>
        </div>
        <button
          onClick={() => {
            resetForm();
            setEditingTicket(null);
            setShowModal(true);
          }}
          className="flex items-center gap-2 bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white font-semibold px-4 py-2.5 rounded-lg shadow-lg shadow-red-500/20 transition"
        >
          <Plus className="w-4 h-4" />
          New Ticket
        </button>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl border border-slate-200 p-4">
        <div className="flex flex-wrap gap-3">
          <div className="flex-1 min-w-[240px] relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search tickets by company, concern, or anydesk..."
              className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-red-500/20 focus:border-red-500 outline-none"
            />
          </div>
          <div className="relative">
            <Filter className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="pl-10 pr-8 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-red-500/20 focus:border-red-500 outline-none bg-white"
            >
              <option value="ALL">All Status</option>
              <option value="DONE">Done</option>
              <option value="ON GOING">On Going</option>
              <option value="PENDING">Pending</option>
              <option value="OPEN">Open</option>
            </select>
          </div>
          <select
            value={priorityFilter}
            onChange={(e) => setPriorityFilter(e.target.value)}
            className="px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-red-500/20 focus:border-red-500 outline-none bg-white"
          >
            <option value="ALL">All Priority</option>
            <option value="RAB">RAB</option>
            <option value="THD">THD</option>
            <option value="EBT">EBT</option>
          </select>
          <button className="flex items-center gap-2 px-4 py-2 border border-slate-300 rounded-lg hover:bg-slate-50 text-slate-700">
            <Download className="w-4 h-4" />
            Export
          </button>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 border-b border-slate-200">
              <tr>
                <th className="text-left px-4 py-3 font-semibold text-slate-700">#</th>
                <th className="text-left px-4 py-3 font-semibold text-slate-700">Date</th>
                <th className="text-left px-4 py-3 font-semibold text-slate-700">Company</th>
                <th className="text-left px-4 py-3 font-semibold text-slate-700">Concern</th>
                <th className="text-left px-4 py-3 font-semibold text-slate-700">Anydesk | PC</th>
                <th className="text-left px-4 py-3 font-semibold text-slate-700">Status</th>
                <th className="text-left px-4 py-3 font-semibold text-slate-700">Completed</th>
                <th className="text-left px-4 py-3 font-semibold text-slate-700">Remarks</th>
                <th className="text-left px-4 py-3 font-semibold text-slate-700">Communication</th>
                <th className="text-left px-4 py-3 font-semibold text-slate-700">Priority</th>
                <th className="text-center px-4 py-3 font-semibold text-slate-700">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredTickets.length === 0 ? (
                <tr>
                  <td colSpan={11} className="text-center py-12 text-slate-500">
                    No tickets found
                  </td>
                </tr>
              ) : (
                filteredTickets.map((ticket) => (
                  <tr key={ticket.id} className="hover:bg-slate-50 transition">
                    <td className="px-4 py-3 text-slate-600">{ticket.id}</td>
                    <td className="px-4 py-3 text-slate-700 whitespace-nowrap">{ticket.date}</td>
                    <td className="px-4 py-3 font-medium text-slate-900">{ticket.company}</td>
                    <td className="px-4 py-3 text-slate-700 max-w-xs">{ticket.concern}</td>
                    <td className="px-4 py-3 text-slate-600 font-mono text-xs">
                      {ticket.anydeskOrPc || "—"}
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={`inline-flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-full border ${getStatusColor(
                          ticket.status
                        )}`}
                      >
                        {ticket.status === "DONE" && "✓"}
                        {ticket.status}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-slate-700 whitespace-nowrap">
                      {ticket.completionDate || "—"}
                    </td>
                    <td className="px-4 py-3 text-slate-600 max-w-xs truncate">
                      {ticket.remarks || "—"}
                    </td>
                    <td className="px-4 py-3 text-slate-600 max-w-xs truncate">
                      {ticket.communication || "—"}
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={`inline-block text-xs font-semibold px-2.5 py-1 rounded-full border ${getPriorityColor(
                          ticket.priority
                        )}`}
                      >
                        {ticket.priority}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-center gap-1">
                        <button
                          onClick={() => openEditModal(ticket)}
                          className="p-1.5 rounded-lg hover:bg-blue-50 text-slate-600 hover:text-blue-600 transition"
                          title="Edit"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => {
                            if (confirm(`Delete ticket #${ticket.id}?`)) {
                              onDeleteTicket(ticket.id);
                            }
                          }}
                          className="p-1.5 rounded-lg hover:bg-red-50 text-slate-600 hover:text-red-600 transition"
                          title="Delete"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-slate-200 flex items-center justify-between sticky top-0 bg-white">
              <h3 className="text-xl font-bold text-slate-900">
                {editingTicket ? "Edit Ticket" : "Create New Ticket"}
              </h3>
              <button
                onClick={() => {
                  setShowModal(false);
                  setEditingTicket(null);
                }}
                className="p-2 rounded-lg hover:bg-slate-100 text-slate-500"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-6 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-sm font-medium text-slate-700">Date *</label>
                  <input
                    type="text"
                    value={formData.date}
                    onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                    placeholder="MM/DD/YYYY"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-red-500/20 focus:border-red-500 outline-none"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-sm font-medium text-slate-700">Company *</label>
                  <input
                    type="text"
                    value={formData.company}
                    onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-red-500/20 focus:border-red-500 outline-none"
                  />
                </div>
                <div className="space-y-1.5 md:col-span-2">
                  <label className="text-sm font-medium text-slate-700">Concern *</label>
                  <input
                    type="text"
                    value={formData.concern}
                    onChange={(e) => setFormData({ ...formData, concern: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-red-500/20 focus:border-red-500 outline-none"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-sm font-medium text-slate-700">Anydesk | PC</label>
                  <input
                    type="text"
                    value={formData.anydeskOrPc}
                    onChange={(e) => setFormData({ ...formData, anydeskOrPc: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-red-500/20 focus:border-red-500 outline-none"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-sm font-medium text-slate-700">Completion Date</label>
                  <input
                    type="text"
                    value={formData.completionDate}
                    onChange={(e) => setFormData({ ...formData, completionDate: e.target.value })}
                    placeholder="MM/DD/YYYY"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-red-500/20 focus:border-red-500 outline-none"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-sm font-medium text-slate-700">Status *</label>
                  <select
                    value={formData.status}
                    onChange={(e) =>
                      setFormData({ ...formData, status: e.target.value as TicketType["status"] })
                    }
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-red-500/20 focus:border-red-500 outline-none bg-white"
                  >
                    <option value="OPEN">Open</option>
                    <option value="ON GOING">On Going</option>
                    <option value="PENDING">Pending</option>
                    <option value="DONE">Done</option>
                  </select>
                </div>
                <div className="space-y-1.5">
                  <label className="text-sm font-medium text-slate-700">Priority *</label>
                  <select
                    value={formData.priority}
                    onChange={(e) =>
                      setFormData({ ...formData, priority: e.target.value as TicketType["priority"] })
                    }
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-red-500/20 focus:border-red-500 outline-none bg-white"
                  >
                    <option value="RAB">RAB</option>
                    <option value="THD">THD</option>
                    <option value="EBT">EBT</option>
                  </select>
                </div>
                <div className="space-y-1.5">
                  <label className="text-sm font-medium text-slate-700">Communication</label>
                  <input
                    type="text"
                    value={formData.communication}
                    onChange={(e) => setFormData({ ...formData, communication: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-red-500/20 focus:border-red-500 outline-none"
                  />
                </div>
                <div className="space-y-1.5 md:col-span-2">
                  <label className="text-sm font-medium text-slate-700">Remarks</label>
                  <textarea
                    value={formData.remarks}
                    onChange={(e) => setFormData({ ...formData, remarks: e.target.value })}
                    rows={3}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-red-500/20 focus:border-red-500 outline-none resize-none"
                  />
                </div>
              </div>
            </div>
            <div className="p-6 border-t border-slate-200 flex items-center justify-end gap-3 sticky bottom-0 bg-white">
              <button
                onClick={() => {
                  setShowModal(false);
                  setEditingTicket(null);
                }}
                className="px-4 py-2 border border-slate-300 rounded-lg hover:bg-slate-50 text-slate-700 font-medium"
              >
                Cancel
              </button>
              <button
                onClick={editingTicket ? handleUpdate : handleCreate}
                className="flex items-center gap-2 bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white font-semibold px-5 py-2 rounded-lg shadow-lg shadow-red-500/20 transition"
              >
                <Save className="w-4 h-4" />
                {editingTicket ? "Update Ticket" : "Create Ticket"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
