import { LayoutDashboard, Ticket, LogOut, BarChart3, Settings, HelpCircle } from "lucide-react";

interface SidebarProps {
  activeTab: "dashboard" | "tickets" | "analytics" | "settings";
  onTabChange: (tab: "dashboard" | "tickets" | "analytics" | "settings") => void;
  user: { name: string; email: string; role: string };
  onLogout: () => void;
}

export default function Sidebar({ activeTab, onTabChange, user, onLogout }: SidebarProps) {
  const navItems = [
    { id: "dashboard" as const, label: "Dashboard", icon: LayoutDashboard },
    { id: "tickets" as const, label: "Support Tickets", icon: Ticket },
    { id: "analytics" as const, label: "Analytics", icon: BarChart3 },
    { id: "settings" as const, label: "Settings", icon: Settings },
  ];

  return (
    <aside className="w-64 bg-white border-r border-slate-200 flex flex-col h-screen sticky top-0">
      {/* Logo */}
      <div className="p-6 border-b border-slate-200">
        <div className="flex items-center gap-3">
          <div className="bg-gradient-to-br from-red-500 to-red-600 p-2 rounded-xl shadow-lg shadow-red-500/20">
            <Ticket className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="font-bold text-slate-900">Support Tracker</h1>
            <p className="text-xs text-slate-500">v2.0.1 · Laravel + React</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-1">
        <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider px-3 mb-2">
          Main Menu
        </p>
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => onTabChange(item.id)}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition ${
              activeTab === item.id
                ? "bg-red-50 text-red-700 border border-red-200"
                : "text-slate-600 hover:bg-slate-50"
            }`}
          >
            <item.icon className={`w-4 h-4 ${activeTab === item.id ? "text-red-600" : ""}`} />
            {item.label}
          </button>
        ))}

        <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider px-3 mb-2 mt-6">
          Support
        </p>
        <button className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-slate-600 hover:bg-slate-50 transition">
          <HelpCircle className="w-4 h-4" />
          Help & Docs
        </button>
      </nav>

      {/* User Profile */}
      <div className="p-4 border-t border-slate-200">
        <div className="flex items-center gap-3 p-3 rounded-lg bg-slate-50">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-red-500 to-red-600 flex items-center justify-center text-white font-semibold">
            {user.name.charAt(0)}
          </div>
          <div className="flex-1 min-w-0">
            <div className="font-semibold text-slate-900 text-sm truncate">{user.name}</div>
            <div className="text-xs text-slate-500 truncate">{user.role}</div>
          </div>
          <button
            onClick={onLogout}
            title="Logout"
            className="p-2 rounded-lg hover:bg-slate-200 text-slate-600 transition"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>
    </aside>
  );
}
