import { Ticket, TrendingUp, CheckCircle2, Activity } from "lucide-react";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
} from "recharts";
import { Ticket as TicketType } from "../types";
import { getStatusColor, getPriorityColor } from "../api";

interface DashboardProps {
  tickets: TicketType[];
}

const COLORS = ["#ef4444", "#8b5cf6", "#f97316", "#10b981"];

export default function Dashboard({ tickets }: DashboardProps) {
  const totalTickets = tickets.length;
  const doneTickets = tickets.filter((t) => t.status === "DONE").length;
  const ongoingTickets = tickets.filter((t) => t.status === "ON GOING").length;
  const completionRate = totalTickets > 0 ? Math.round((doneTickets / totalTickets) * 100) : 0;

  // Tickets by date
  const ticketsByDate: Record<string, number> = {};
  tickets.forEach((t) => {
    ticketsByDate[t.date] = (ticketsByDate[t.date] || 0) + 1;
  });
  const dateData = Object.entries(ticketsByDate)
    .sort(([a], [b]) => new Date(a).getTime() - new Date(b).getTime())
    .map(([date, count]) => ({ date, count }));

  // Tickets by company
  const ticketsByCompany: Record<string, number> = {};
  tickets.forEach((t) => {
    ticketsByCompany[t.company] = (ticketsByCompany[t.company] || 0) + 1;
  });
  const companyData = Object.entries(ticketsByCompany)
    .sort(([, a], [, b]) => b - a)
    .map(([name, value]) => ({ name, value }));

  // Tickets by priority
  const byPriority: Record<string, number> = { RAB: 0, THD: 0, EBT: 0 };
  tickets.forEach((t) => {
    if (t.priority in byPriority) byPriority[t.priority]++;
  });
  const priorityData = Object.entries(byPriority).map(([name, value]) => ({ name, value }));

  const stats = [
    {
      label: "Total Tickets",
      value: totalTickets,
      icon: Ticket,
      color: "bg-blue-500",
      bgColor: "bg-blue-50",
      textColor: "text-blue-600",
      change: "+12%",
      trend: "up",
    },
    {
      label: "Completed",
      value: doneTickets,
      icon: CheckCircle2,
      color: "bg-green-500",
      bgColor: "bg-green-50",
      textColor: "text-green-600",
      change: "+8%",
      trend: "up",
    },
    {
      label: "On Going",
      value: ongoingTickets,
      icon: Activity,
      color: "bg-orange-500",
      bgColor: "bg-orange-50",
      textColor: "text-orange-600",
      change: "-3%",
      trend: "down",
    },
    {
      label: "Completion Rate",
      value: `${completionRate}%`,
      icon: TrendingUp,
      color: "bg-purple-500",
      bgColor: "bg-purple-50",
      textColor: "text-purple-600",
      change: "+5%",
      trend: "up",
    },
  ];

  const recentTickets = [...tickets].sort((a, b) => b.id - a.id).slice(0, 5);

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Dashboard Overview</h1>
          <p className="text-slate-500 mt-1">Track your IT support metrics at a glance</p>
        </div>
        <div className="flex items-center gap-2 text-sm bg-white border border-slate-200 px-4 py-2 rounded-lg shadow-sm">
          <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
          <span className="text-slate-600">Live Data</span>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, i) => (
          <div
            key={i}
            className="bg-white rounded-xl border border-slate-200 p-5 hover:shadow-lg transition-shadow"
          >
            <div className="flex items-start justify-between mb-4">
              <div className={`${stat.bgColor} p-2.5 rounded-lg`}>
                <stat.icon className={`w-5 h-5 ${stat.textColor}`} />
              </div>
              <span
                className={`text-xs font-semibold px-2 py-1 rounded-full ${
                  stat.trend === "up" ? "text-green-700 bg-green-50" : "text-red-700 bg-red-50"
                }`}
              >
                {stat.change}
              </span>
            </div>
            <div className="text-3xl font-bold text-slate-900 mb-1">{stat.value}</div>
            <div className="text-sm text-slate-500">{stat.label}</div>
          </div>
        ))}
      </div>

      {/* Charts Row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Tickets by Date */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 lg:col-span-2">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-slate-900">Tickets Activity</h3>
            <span className="text-xs text-slate-500">Last 7 days</span>
          </div>
          <ResponsiveContainer width="100%" height={250}>
            <AreaChart data={dateData}>
              <defs>
                <linearGradient id="colorCount" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#ef4444" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#ef4444" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="date" tick={{ fontSize: 12 }} stroke="#94a3b8" />
              <YAxis tick={{ fontSize: 12 }} stroke="#94a3b8" />
              <Tooltip
                contentStyle={{ backgroundColor: "white", border: "1px solid #e2e8f0", borderRadius: "8px" }}
              />
              <Area type="monotone" dataKey="count" stroke="#ef4444" strokeWidth={2} fill="url(#colorCount)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Tickets by Priority */}
        <div className="bg-white rounded-xl border border-slate-200 p-5">
          <h3 className="font-semibold text-slate-900 mb-4">By Priority</h3>
          <ResponsiveContainer width="100%" height={180}>
            <PieChart>
              <Pie
                data={priorityData}
                dataKey="value"
                nameKey="name"
                cx="50%"
                cy="50%"
                innerRadius={40}
                outerRadius={70}
                paddingAngle={3}
              >
                {priorityData.map((_, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
          <div className="space-y-1.5 mt-2">
            {priorityData.map((item, i) => (
              <div key={item.name} className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <div
                    className="w-2.5 h-2.5 rounded-full"
                    style={{ backgroundColor: COLORS[i] }}
                  />
                  <span className="text-slate-700">{item.name}</span>
                </div>
                <span className="font-semibold text-slate-900">{item.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Charts Row 2 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* By Company */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 lg:col-span-2">
          <h3 className="font-semibold text-slate-900 mb-4">Tickets by Company</h3>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={companyData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="name" tick={{ fontSize: 11 }} stroke="#94a3b8" />
              <YAxis tick={{ fontSize: 12 }} stroke="#94a3b8" />
              <Tooltip
                contentStyle={{ backgroundColor: "white", border: "1px solid #e2e8f0", borderRadius: "8px" }}
              />
              <Bar dataKey="value" fill="#ef4444" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Recent Tickets */}
        <div className="bg-white rounded-xl border border-slate-200 p-5">
          <h3 className="font-semibold text-slate-900 mb-4">Recent Tickets</h3>
          <div className="space-y-3">
            {recentTickets.map((ticket) => (
              <div
                key={ticket.id}
                className="p-3 rounded-lg bg-slate-50 border border-slate-100 hover:bg-slate-100 transition"
              >
                <div className="flex items-start justify-between mb-1">
                  <span className="text-xs font-semibold text-slate-900 truncate flex-1">
                    {ticket.company}
                  </span>
                  <span
                    className={`text-xs font-semibold px-2 py-0.5 rounded-full border ${getStatusColor(
                      ticket.status
                    )}`}
                  >
                    {ticket.status}
                  </span>
                </div>
                <div className="text-xs text-slate-600 truncate">{ticket.concern}</div>
                <div className="flex items-center justify-between mt-2">
                  <span className="text-xs text-slate-400">{ticket.date}</span>
                  <span
                    className={`text-xs font-semibold px-2 py-0.5 rounded-full border ${getPriorityColor(
                      ticket.priority
                    )}`}
                  >
                    {ticket.priority}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
