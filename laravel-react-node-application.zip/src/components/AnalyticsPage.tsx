import {
  PieChart,
  Pie,
  Cell,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  RadarChart,
  Radar,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
} from "recharts";
import { TrendingUp, Clock, CheckCircle2, Target, Zap } from "lucide-react";
import { Ticket as TicketType } from "../types";

interface AnalyticsPageProps {
  tickets: TicketType[];
}

const COLORS = ["#ef4444", "#8b5cf6", "#f97316", "#10b981", "#3b82f6", "#ec4899"];

export default function AnalyticsPage({ tickets }: AnalyticsPageProps) {
  const totalTickets = tickets.length;
  const doneTickets = tickets.filter((t) => t.status === "DONE").length;
  const ongoingTickets = tickets.filter((t) => t.status === "ON GOING").length;
  const pendingTickets = tickets.filter(
    (t) => t.status === "PENDING" || t.status === "OPEN"
  ).length;
  const completionRate = totalTickets > 0 ? ((doneTickets / totalTickets) * 100).toFixed(1) : "0";

  // By priority
  const byPriority: Record<string, number> = { RAB: 0, THD: 0, EBT: 0 };
  tickets.forEach((t) => {
    if (t.priority in byPriority) byPriority[t.priority]++;
  });
  const priorityData = Object.entries(byPriority).map(([name, value]) => ({ name, value }));

  // By company
  const ticketsByCompany: Record<string, number> = {};
  tickets.forEach((t) => {
    ticketsByCompany[t.company] = (ticketsByCompany[t.company] || 0) + 1;
  });
  const companyData = Object.entries(ticketsByCompany)
    .sort(([, a], [, b]) => b - a)
    .map(([name, value]) => ({ name, value }));

  // By status
  const byStatus: Record<string, number> = { DONE: 0, "ON GOING": 0, PENDING: 0, OPEN: 0 };
  tickets.forEach((t) => {
    if (t.status in byStatus) byStatus[t.status]++;
  });
  const statusData = Object.entries(byStatus)
    .filter(([, v]) => v > 0)
    .map(([name, value]) => ({ name, value }));

  // By date
  const ticketsByDate: Record<string, number> = {};
  tickets.forEach((t) => {
    ticketsByDate[t.date] = (ticketsByDate[t.date] || 0) + 1;
  });
  const dateData = Object.entries(ticketsByDate)
    .sort(([a], [b]) => new Date(a).getTime() - new Date(b).getTime())
    .map(([date, count]) => ({ date, count }));

  // Priority vs status breakdown
  const radarData = ["RAB", "THD", "EBT"].map((p) => ({
    priority: p,
    done: tickets.filter((t) => t.priority === p && t.status === "DONE").length,
    ongoing: tickets.filter((t) => t.priority === p && t.status === "ON GOING").length,
    pending: tickets.filter((t) => t.priority === p && (t.status === "PENDING" || t.status === "OPEN")).length,
  }));

  const kpis = [
    {
      label: "Completion Rate",
      value: `${completionRate}%`,
      icon: Target,
      color: "from-green-500 to-emerald-600",
      bg: "bg-green-50",
      text: "text-green-600",
    },
    {
      label: "Total Tickets",
      value: totalTickets,
      icon: TrendingUp,
      color: "from-blue-500 to-blue-600",
      bg: "bg-blue-50",
      text: "text-blue-600",
    },
    {
      label: "Avg Resolution",
      value: "2.5 days",
      icon: Clock,
      color: "from-purple-500 to-purple-600",
      bg: "bg-purple-50",
      text: "text-purple-600",
    },
    {
      label: "Response Time",
      value: "15 min",
      icon: Zap,
      color: "from-orange-500 to-orange-600",
      bg: "bg-orange-50",
      text: "text-orange-600",
    },
  ];

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Analytics & Reports</h1>
          <p className="text-slate-500 mt-1">Comprehensive insights into support operations</p>
        </div>
        <select className="px-4 py-2 border border-slate-300 rounded-lg bg-white text-sm">
          <option>Last 7 days</option>
          <option>Last 30 days</option>
          <option>This month</option>
          <option>All time</option>
        </select>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {kpis.map((kpi, i) => (
          <div
            key={i}
            className="bg-white rounded-xl border border-slate-200 p-5 hover:shadow-lg transition-shadow"
          >
            <div className="flex items-center gap-3 mb-3">
              <div className={`${kpi.bg} p-2.5 rounded-lg`}>
                <kpi.icon className={`w-5 h-5 ${kpi.text}`} />
              </div>
              <span className="text-sm text-slate-500">{kpi.label}</span>
            </div>
            <div className="text-3xl font-bold text-slate-900">{kpi.value}</div>
          </div>
        ))}
      </div>

      {/* Charts Row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Priority Distribution */}
        <div className="bg-white rounded-xl border border-slate-200 p-5">
          <h3 className="font-semibold text-slate-900 mb-4">Priority Distribution</h3>
          <ResponsiveContainer width="100%" height={220}>
            <PieChart>
              <Pie
                data={priorityData}
                dataKey="value"
                nameKey="name"
                cx="50%"
                cy="50%"
                innerRadius={50}
                outerRadius={80}
                paddingAngle={3}
                label={(entry) => entry.name}
              >
                {priorityData.map((_, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip
                contentStyle={{
                  backgroundColor: "white",
                  border: "1px solid #e2e8f0",
                  borderRadius: "8px",
                }}
              />
            </PieChart>
          </ResponsiveContainer>
          <div className="space-y-2 mt-3">
            {priorityData.map((item, i) => (
              <div key={item.name} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: COLORS[i] }} />
                  <span className="text-sm text-slate-700">{item.name}</span>
                </div>
                <span className="text-sm font-semibold text-slate-900">{item.value}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Status Breakdown */}
        <div className="bg-white rounded-xl border border-slate-200 p-5">
          <h3 className="font-semibold text-slate-900 mb-4">Status Overview</h3>
          <ResponsiveContainer width="100%" height={220}>
            <PieChart>
              <Pie
                data={statusData}
                dataKey="value"
                nameKey="name"
                cx="50%"
                cy="50%"
                outerRadius={80}
                paddingAngle={2}
              >
                {statusData.map((_, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[(index + 1) % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip
                contentStyle={{
                  backgroundColor: "white",
                  border: "1px solid #e2e8f0",
                  borderRadius: "8px",
                }}
              />
            </PieChart>
          </ResponsiveContainer>
          <div className="space-y-2 mt-3">
            {statusData.map((item, i) => (
              <div key={item.name} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: COLORS[(i + 1) % COLORS.length] }} />
                  <span className="text-sm text-slate-700">{item.name}</span>
                </div>
                <span className="text-sm font-semibold text-slate-900">{item.value}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Radar - Priority vs Status */}
        <div className="bg-white rounded-xl border border-slate-200 p-5">
          <h3 className="font-semibold text-slate-900 mb-4">Priority Analysis</h3>
          <ResponsiveContainer width="100%" height={220}>
            <RadarChart data={radarData}>
              <PolarGrid stroke="#e2e8f0" />
              <PolarAngleAxis dataKey="priority" tick={{ fontSize: 12 }} />
              <PolarRadiusAxis tick={{ fontSize: 10 }} />
              <Radar name="Done" dataKey="done" stroke="#10b981" fill="#10b981" fillOpacity={0.3} />
              <Radar name="On Going" dataKey="ongoing" stroke="#f97316" fill="#f97316" fillOpacity={0.3} />
              <Radar name="Pending" dataKey="pending" stroke="#ef4444" fill="#ef4444" fillOpacity={0.3} />
              <Tooltip
                contentStyle={{
                  backgroundColor: "white",
                  border: "1px solid #e2e8f0",
                  borderRadius: "8px",
                }}
              />
            </RadarChart>
          </ResponsiveContainer>
          <div className="flex items-center justify-center gap-4 mt-2 text-xs">
            <div className="flex items-center gap-1.5">
              <div className="w-2.5 h-2.5 rounded-full bg-green-500"></div>
              <span className="text-slate-700">Done</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-2.5 h-2.5 rounded-full bg-orange-500"></div>
              <span className="text-slate-700">On Going</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-2.5 h-2.5 rounded-full bg-red-500"></div>
              <span className="text-slate-700">Pending</span>
            </div>
          </div>
        </div>
      </div>

      {/* Charts Row 2 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Activity Timeline */}
        <div className="bg-white rounded-xl border border-slate-200 p-5">
          <h3 className="font-semibold text-slate-900 mb-4">Ticket Activity Timeline</h3>
          <ResponsiveContainer width="100%" height={280}>
            <AreaChart data={dateData}>
              <defs>
                <linearGradient id="colorCount2" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="date" tick={{ fontSize: 11 }} stroke="#94a3b8" />
              <YAxis tick={{ fontSize: 12 }} stroke="#94a3b8" />
              <Tooltip
                contentStyle={{
                  backgroundColor: "white",
                  border: "1px solid #e2e8f0",
                  borderRadius: "8px",
                }}
              />
              <Area
                type="monotone"
                dataKey="count"
                stroke="#8b5cf6"
                strokeWidth={2}
                fill="url(#colorCount2)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Top Companies */}
        <div className="bg-white rounded-xl border border-slate-200 p-5">
          <h3 className="font-semibold text-slate-900 mb-4">Top Companies</h3>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={companyData} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" horizontal={false} />
              <XAxis type="number" tick={{ fontSize: 12 }} stroke="#94a3b8" />
              <YAxis
                type="category"
                dataKey="name"
                tick={{ fontSize: 11 }}
                stroke="#94a3b8"
                width={130}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: "white",
                  border: "1px solid #e2e8f0",
                  borderRadius: "8px",
                }}
              />
              <Bar dataKey="value" fill="#ef4444" radius={[0, 6, 6, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Summary */}
      <div className="bg-gradient-to-br from-red-500 to-red-600 rounded-xl p-6 text-white shadow-xl shadow-red-500/20">
        <div className="flex items-start justify-between">
          <div>
            <h3 className="text-xl font-bold mb-2">Performance Summary</h3>
            <p className="text-white/90 leading-relaxed max-w-2xl">
              {totalTickets} total tickets processed with a {completionRate}% completion rate. 
              Top performing category: <strong>RAB</strong> priority tickets. 
              Average resolution time is within SLA targets.
            </p>
          </div>
          <CheckCircle2 className="w-12 h-12 text-white/30 flex-shrink-0" />
        </div>
        <div className="grid grid-cols-3 gap-4 mt-6 pt-6 border-t border-white/20">
          <div>
            <div className="text-white/70 text-sm">Total Handled</div>
            <div className="text-3xl font-bold">{totalTickets}</div>
          </div>
          <div>
            <div className="text-white/70 text-sm">Successfully Completed</div>
            <div className="text-3xl font-bold">{doneTickets}</div>
          </div>
          <div>
            <div className="text-white/70 text-sm">Requires Attention</div>
            <div className="text-3xl font-bold">{ongoingTickets + pendingTickets}</div>
          </div>
        </div>
      </div>
    </div>
  );
}
