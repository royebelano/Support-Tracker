import { useState } from "react";
import { Shield, Mail, Lock, AlertCircle, Server, Code2, Database, BarChart3 } from "lucide-react";
import { api } from "../api";

interface LoginPageProps {
  onLogin: (user: { id: number; name: string; email: string; role: string }) => void;
}

export default function LoginPage({ onLogin }: LoginPageProps) {
  const [email, setEmail] = useState("admin@company.com");
  const [password, setPassword] = useState("admin123");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      const user = await api.login(email, password);
      onLogin(user);
    } catch (err: any) {
      setError(err.message || "Login failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex">
      {/* Left - Login Form */}
      <div className="flex-1 flex items-center justify-center p-8 bg-gradient-to-br from-slate-50 to-slate-100">
        <div className="w-full max-w-md">
          <div className="mb-8">
            <div className="flex items-center gap-3 mb-2">
              <div className="bg-gradient-to-br from-red-500 to-red-600 p-2.5 rounded-xl shadow-lg shadow-red-500/20">
                <Shield className="w-6 h-6 text-white" />
              </div>
              <h1 className="text-2xl font-bold text-slate-900">Support Tracker</h1>
            </div>
            <p className="text-slate-500 ml-14">Sign in to your account to continue</p>
          </div>

          <form onSubmit={handleSubmit} className="bg-white rounded-2xl shadow-xl shadow-slate-200/50 border border-slate-200 p-8 space-y-5">
            <div className="mb-6">
              <h2 className="text-xl font-semibold text-slate-900">Welcome back</h2>
              <p className="text-sm text-slate-500 mt-1">Enter your credentials to access the dashboard</p>
            </div>

            {error && (
              <div className="flex items-center gap-2 p-3 rounded-lg bg-red-50 border border-red-200 text-red-700 text-sm">
                <AlertCircle className="w-4 h-4 flex-shrink-0" />
                {error}
              </div>
            )}

            <div className="space-y-1.5">
              <label className="text-sm font-medium text-slate-700">Email</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-red-500/20 focus:border-red-500 outline-none transition"
                  placeholder="admin@company.com"
                  required
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-sm font-medium text-slate-700">Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-red-500/20 focus:border-red-500 outline-none transition"
                  placeholder="••••••••"
                  required
                />
              </div>
            </div>

            <div className="flex items-center justify-between text-sm">
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" className="w-4 h-4 rounded border-slate-300 text-red-600 focus:ring-red-500" />
                <span className="text-slate-600">Remember me</span>
              </label>
              <a href="#" className="text-red-600 hover:text-red-700 font-medium">
                Forgot password?
              </a>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white font-semibold py-2.5 rounded-lg shadow-lg shadow-red-500/20 transition disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {loading ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Signing in...
                </>
              ) : (
                "Sign in"
              )}
            </button>

            <div className="pt-4 border-t border-slate-200">
              <p className="text-xs text-slate-500 text-center mb-2">Demo credentials:</p>
              <div className="space-y-1 text-xs text-slate-600 bg-slate-50 rounded-lg p-3">
                <div>👤 <span className="font-medium">Admin:</span> admin@company.com / admin123</div>
                <div>👤 <span className="font-medium">Agent:</span> agent@company.com / agent123</div>
              </div>
            </div>
          </form>
        </div>
      </div>

      {/* Right - Branding */}
      <div className="hidden lg:flex flex-1 bg-gradient-to-br from-red-600 via-red-700 to-rose-800 relative overflow-hidden items-center justify-center p-12">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 left-0 w-72 h-72 bg-white rounded-full mix-blend-overlay filter blur-3xl"></div>
          <div className="absolute bottom-0 right-0 w-96 h-96 bg-white rounded-full mix-blend-overlay filter blur-3xl"></div>
        </div>

        <div className="relative z-10 max-w-lg text-white">
          <div className="flex items-center gap-3 mb-8">
            <div className="bg-white/20 backdrop-blur-sm p-3 rounded-xl">
              <Server className="w-8 h-8" />
            </div>
            <div>
              <h2 className="text-3xl font-bold">Laravel + React</h2>
              <p className="text-white/80">Full Stack IT Support System</p>
            </div>
          </div>

          <p className="text-lg text-white/90 mb-8 leading-relaxed">
            A complete IT support ticket tracking solution with real-time analytics, multi-user authentication, and comprehensive reporting.
          </p>

          <div className="grid grid-cols-3 gap-4">
            {[
              { icon: Code2, label: "React.js", sub: "Frontend UI" },
              { icon: Server, label: "Laravel", sub: "REST API" },
              { icon: Database, label: "MySQL", sub: "Database" },
              { icon: BarChart3, label: "Analytics", sub: "Insights" },
              { icon: Shield, label: "Sanctum", sub: "Auth" },
              { icon: Mail, label: "Node.js", sub: "Real-time" },
            ].map((item, i) => (
              <div key={i} className="bg-white/10 backdrop-blur-sm rounded-xl p-3 border border-white/20">
                <item.icon className="w-5 h-5 mb-2" />
                <div className="font-semibold text-sm">{item.label}</div>
                <div className="text-xs text-white/70">{item.sub}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
